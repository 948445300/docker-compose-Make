/*****************************************************
 * Author  : Administrator
 * Version : 1.0
 * Date    :  2015/3/21
 ****************************************************/
//Note that smtp appender needs nodemailer to work.
//If you haven't got nodemailer installed, you'll get cryptic
//"cannot find module" errors when using the smtp appender
var log4js = require('../lib/log4js')
		, log;
log4js.configure({
	"appenders": [
		{
			type: "console",
			category: "test",
			"layout": {
				"type": "pattern",
				"pattern": "%[[%d{yyyy-MM-dd hh:mm:ss}] [%p]%] %m"
			}
		},
		{
			"type": "redis",
			"host": "127.0.0.1",
			"port": 6379,
			"channel": "log",
			"category": "redis",
			"layout": {
				"type": "pattern",
				"pattern": "%d{yyyy-MM-dd hh:mm:ss}#%p#%m"
			}
		}
	]
});
log = log4js.getLogger("test");

function doTheLogging(x) {
	log.info("Logging something %d", x);
	//logmailer.info("Logging something %d", x);
}

for (var i = 0; i < 500; i++) {
	doTheLogging(i);
}
